// import java.util.StringJoiner;
// import static java.lang.Math.*;
// import static java.lang.System.*;
import java.util.*;
import static java.util.Objects.*;

class Main {
  public static void main(String[] args) {
    //8-8
    // System.out.print(1);
    // System.out.print(2);
    // try {
    //   System.out.print(3);
    //   System.out.print(0/0);
    //   System.out.print(4);
    // } catch(ArithmeticExcepton ae) {
    //   ae.printStackTrace();
    //   System.out.println("예외메시지 : " + ae.getMessage());
    // }
    // System.out.println(6);

    //8-15
    // File f = createFile(args[0]);
    // System.out.println(f.getName() + " 파일이 성공적으로 생성되었습니다. ");
  // }
  // 8-15
  // static File createFile(String fileName) {
  //   try {
  //     if(fileName == null || fileName.equals(""))
  //       throw new Exception("파일이름이 유효하지 않습니다.");
  //   } catch (Exception e) {
  //     fileName = "제목없음.txt";
  //   } finally {
  //     File f = new File(fileName);
  //     createNewFile(f);
  //     return f;
  //   }
  // }

  // static void createNewFile(File f) {
  //   try {
  //     f.createNewFile();
  //   } catch(Exception e) {  }
  //8-22
  //   try {
  //     method1();
  //   } catch ( Exception e) {
  //     System.out.println("main메서드에서 예외가 처되었습니다.");
  //   }
  // }
  // static void method1() throws Exception {
  //   try {
  //     throw new Exception();
  //   } catch (Exception e) {
  //     System.out.println("method1메서드에서 예외가 처리되었습니다.");
  //     throw e;
  //   }

    //9-1
    // Value v1 = new Value(10);
    // Value v2 = new Value(10);

    // if (v1.equals(v2)) 
    //   System.out.println("v1 과 v2 는 같습니다.");
    // else
    //   System.out.println("v1 과 v2 는 다릅니다.");

    // v2 = v1;
    // if (v1.equals(v2))
    //   System.out.println("v1 과 v2 는 같습니다.");
    // else
    //   System.out.println("v1 과 v2 는 다릅니다.");


    //9-14
    // String animals = "dog,cat,bear";
    // String[] arr = animals.split(",");
    // System.out.println(String.join("-", arr));
    // StringJoiner sj = new StringJoiner("/","[","]");
    // for (String s : arr)
    //   sj.add*(s);

    // System.out.println(sj.toString());

    //9-20
    // double val = 90.7552;
    // out.println("round(" + val + ") = " + round(val));

    // val *= 100;
    // out.println("round(" + val + ") = " + round(val)); //반올림

    // out.println("round(" + val + ")/100 = " + round(val)/100);
    // out.println("round(" + val + ")/100.0 = " + round(val)/100.0);
    // out.println();
    // out.printf("ceil(%3.1f)=%3.1f%n", 1.1, ceil(1.1));
    // out.printf("floor(%3.1f)=%3.1f%n", 1.5, floor(1.5));
    // out.printf("round(%3.1f)=%d%n", 1.1, round(1.1));
    // out.printf("round(%3.1f)=%d%n", 1.5, round(1.5));
    // out.printf("rint(%3.1f)=%f%n", 1.5, rint(1.5));
    // out.printf("round(%3.1f)=%d%n", -1.5, round(-1.5));
    // out.printf("rint(%3.1f)=%f%n", -1.5, rint(-1.5));
    // out.printf("ceil(%3.1f)=%f%n", -1.5, ceil(-1.5));
    // out.printf("floor(%3.1f)=%f%n", -1.5, floor(-1.5));

    //9-23
    // Integer i = new Integer(100);
    // Integer i2 = new Integer(100);

    // System.out.println("i==i2 ? " + (i==i2));
    // System.out.println("i.equals(i2) ? " + i.equals(i2));
    // System.out.println("i.compareTo(i2) = " + i.compareTo(i2));
    // System.out.println("i.toString() = " + i.toString());


    // System.out.println("MAX_VALUE = " + Integer.MAX_VALUE);
    // System.out.println("MIN_VALUE = " + Integer.MIN_VALUE);
    // System.out.println("SIZE = " + Integer.SIZE + " bits");
    // System.out.println("BYTES = " + Integer.BYTES + " bytes");
    // System.out.println("TYPE = " + Integer.TYPE);
    

    //9-26
    String[][] str2D  = new String[][] {{"aaa","bbb"},{"AAA","BBB"}};
    String[][] str2D_2  = new String[][] {{"aaa","bbb"},{"AAA","BBB"}};

    System.out.print("str2D ={");
    for(String[] tmp : str2D)
      System.out.print(Arrays.toString(tmp));
    System.out.println("}");

    System.out.print("str2D_2 = {");
    for(String[] tmp : str2D_2)
      System.out.print(Arrays.toString(tmp));
    System.out.println("}");

    System.out.println("equals(str2D, str2D_2) = " + Objects.equals(str2D, str2D_2));
    System.out.println("deepEquals(str2D, str2D_2) = " + Objects.deepEquals(str2D, str2D_2));
    System.out.println("isNull(null) = "+ isNull(null));
    System.out.println("nonNull(null) = "+ nonNull(null));
    System.out.println("hashCode(null) = "+ Objects.hashCode(null));
    System.out.println("toString(null) = "+ Objects.toString(null));
    System.out.println("toString(null, \"\") = " + Objects.toString(null, ""));

    Comparator c = String.CASE_INSENSITIVE_ORDER;

    System.out.println("compare(\"aa\",\"bb\") = " + compare("aa","bb",c));
    System.out.println("compare(\"bb\",\"aa\") = " + compare("bb","aa",c));
    System.out.println("compare(\"ab\",\"AB\") = " + compare("ab","AB",c));
  }
}

//9-1
// class Value {
//   int value;
//   Value(int value) {
//     this.value = value;
//   }
// }